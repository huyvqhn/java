package com.sdc.vsiistandard.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sdc.vsiistandard.service.EmployeeService;

@Controller
public class HelloController {

	private static final Logger log = LoggerFactory.getLogger(HelloController.class);
	
	@Autowired
	private EmployeeService employeeService;
	
	public HelloController() {
		
//		this.employeeService = employeeService; EmployeeService employeeService
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String printWelcome(ModelMap model) {

	    Date date = new Date();

	     // display time and date using toString()
	    System.out.println("Start at: " + date);
	    log.debug("Result : {}", employeeService.findByDepartment("dummy"));
	    log.debug("Result : {}", employeeService.findByDepartment("dummya"));
	    log.debug("Result : {}", employeeService.findByDepartment("dummyaa"));
	    
	    date = new Date();
	    System.out.println("End at: " + date);
	    
		model.addAttribute("message", "Spring 3 MVC Hello World");
		return "hello";

	}

	@RequestMapping(value = "/hello/{name:.+}", method = RequestMethod.GET)
	public ModelAndView hello(@PathVariable("name") String name) {

		ModelAndView model = new ModelAndView();
		model.setViewName("hello");
		model.addObject("msg", name);

		return model;

	}

}