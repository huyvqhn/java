package com.sdc.vsiistandard.service.impl;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sdc.vsiistandard.entity.Employee;
import com.sdc.vsiistandard.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Cacheable(value="employee", key="#name")
	public Employee findByDepartment(String name) {
		slowQuery(1000L);
		System.out.println("findByDepartment is running...");
		return new Employee(1,"Le Xuan Mai Anh","SDCC");
	}
	
	private void slowQuery(long seconds){
		try {
            Thread.sleep(seconds);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
	}
}
