package com.sdc.vsiistandard.service;

import com.sdc.vsiistandard.entity.Employee;

public interface EmployeeService {
	
	Employee findByDepartment(String name);
}
